from pathlib import Path
import sys,json,random,csv
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'_lib'))
import xlsxwriter
sources=json.loads((P/'sources_v2.json').read_text(encoding='utf-8'))
sources=[s for s in sources if not s[0].split(' / ')[0] in ['S5','S6','S7','S8','S9','S10','S12','S13']]+[
['S12 / Thiết bị người dùng xác nhận','https://shopee.vn/product/280566046/44719511159','Người dùng xác nhận dùng mẫu Quỷ nhỏ thông thái / Monter Desk AI và gửi 2 ảnh. Đã xác nhận kiểu dáng thân trắng, mặt tím, màn hình chữ nhật; chưa xác minh giá, chip, bộ nhớ, phụ kiện hay khả năng tích hợp. Không dùng giá EchoEar cho mẫu này.'],
['S13 / Ảnh nhận diện thiết bị','Ảnh đính kèm trong hội thoại, 26/10/2026','Tên trên ảnh: Quỷ nhỏ thông thái, Monter Desk AI. Hình trong slide là minh họa kiểu dáng bằng hình khối sửa được, không phải ảnh kỹ thuật hoặc sơ đồ linh kiện. Ảnh không chứng minh chip, kết nối, công suất, độ phân giải, giá hoặc tình trạng tích hợp AnMi.']]
(P/'sources_v2.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf-8')

rng=random.Random(20261026)
rows=[]
for i in range(200):
    group='Sinh viên' if i<140 else 'Công nhân'
    need=rng.choices([1,2,3,4,5],weights=[8,17,30,30,15])[0]
    barrier=rng.choices(['Ngại chia sẻ','Lo riêng tư','Chi phí','Không biết tìm ai','Thiếu thời gian'],weights=[25,24,22,17,12])[0]
    channel=rng.choices(['Web/điện thoại','Thiết bị để bàn','Gặp trực tiếp'],weights=[68,12,20])[0]
    trial=rng.choices(['Có','Cần biết thêm','Không'],weights=[58,30,12])[0]
    rows.append(['MÔ PHỎNG — KHÔNG PHỎNG VẤN',f'SIM-{i+1:03d}',group,need,barrier,channel,trial])
wb=xlsxwriter.Workbook(P/'MO_PHONG_200_phan_hoi_KHONG_PHAI_KHAO_SAT.xlsx')
raw=wb.add_worksheet('MO PHONG 200 dong');summary=wb.add_worksheet('MINH HOA KHONG SUY RONG')
hd=wb.add_format({'bold':True,'font_color':'white','bg_color':'#7F342B','text_wrap':True});wr=wb.add_format({'text_wrap':True});pc=wb.add_format({'num_format':'0.0%'})
headers=['Bản chất dữ liệu','Mã kịch bản','Nhóm mô phỏng','Nhu cầu 1–5 giả lập','Rào cản giả lập','Kênh giả lập','Ý định giả lập']
raw.write_row(0,0,headers,hd);raw.set_column('A:A',40);raw.set_column('B:G',24)
for r,row in enumerate(rows,1):raw.write_row(r,0,row)
raw.autofilter(0,0,200,6);raw.freeze_panes(1,2)
summary.set_column('A:A',55);summary.set_column('B:C',23);summary.set_column('D:D',80)
summary.merge_range('A1:D3','DỮ LIỆU MÔ PHỎNG — KHÔNG PHẢI KẾT QUẢ KHẢO SÁT. Không có người tham gia thật, không có thời gian/địa điểm thu mẫu. Chỉ dùng thử cách phân tích, không dùng làm minh chứng nhu cầu, thẩm định sản phẩm, định giá hay gọi vốn.',hd)
summary.write_row(4,0,['Chỉ tiêu minh họa','Số dòng giả lập','Tỷ lệ giả lập','Cách hiểu'],hd)
stats=[('Nhu cầu >=4/5',sum(r[3]>=4 for r in rows),'COUNTIF(\'MO PHONG 200 dong\'!D2:D201,">=4")'),('Rào cản: lo riêng tư',sum(r[4]=='Lo riêng tư' for r in rows),'COUNTIF(\'MO PHONG 200 dong\'!E2:E201,"Lo riêng tư")'),('Kênh: web/điện thoại',sum(r[5]=='Web/điện thoại' for r in rows),'COUNTIF(\'MO PHONG 200 dong\'!F2:F201,"Web/điện thoại")'),('Ý định: sẵn lòng thử',sum(r[6]=='Có' for r in rows),'COUNTIF(\'MO PHONG 200 dong\'!G2:G201,"Có")')]
for r,(name,count,formula) in enumerate(stats,5):
    summary.write(r,0,name);summary.write_formula(r,1,'='+formula,None,count);summary.write_formula(r,2,f'=B{r+1}/200',pc,count/200);summary.write(r,3,'Tần suất do bộ sinh giả lập, không mô tả thực tế.',wr)
summary.merge_range('A12:D16','Thiết kế giả lập: 140 kịch bản sinh viên + 60 công nhân; các trọng số do người thiết kế chọn để thử công thức, không ước lượng từ nghiên cứu hoặc dữ liệu thực. Seed 20261026 để tái lập. Không gán tên trường/doanh nghiệp hay thời điểm phỏng vấn giả. Muốn báo cáo khảo sát thực, thay bằng phản hồi có đồng ý và phân tích lại trong các sheet khảo sát trống của file tài chính chính.',wr)
chart=wb.add_chart({'type':'bar'});chart.add_series({'categories':['MINH HOA KHONG SUY RONG',5,0,8,0],'values':['MINH HOA KHONG SUY RONG',5,2,8,2],'fill':{'color':'#B97959'}});chart.set_title({'name':'MINH HỌA GIẢ LẬP — không phải khảo sát'});chart.set_legend({'none':True});chart.set_x_axis({'num_format':'0%','max':1});summary.insert_chart('A19',chart)
wb.close()
with (P/'MO_PHONG_200_phan_hoi_KHONG_PHAI_KHAO_SAT.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f);w.writerow(headers);w.writerows(rows)

memo='''# AnMi — Cơ sở kinh doanh và cách bảo vệ số liệu

Bản cập nhật ngày 26/10/2026. Bộ trình chiếu chính vẫn đúng 10 slide, phân bổ 300 giây. Bản ban đầu được giữ trong `ban_dau/`. Tài liệu này hỗ trợ chuẩn bị trả lời giám khảo; không phải phần slide phụ.

## 1. Dữ liệu nào là bằng chứng?

Phải phân biệt ba loại: nghiên cứu công bố độc lập; tài liệu/nguyên mẫu của nhóm; giả định kinh doanh cần kiểm chứng. Ẩn danh là không đưa danh tính ra báo cáo, không biến dữ liệu tự tạo thành khảo sát thật. File mô phỏng bàn giao riêng được ghi nhãn trên tên tệp, từng dòng và bảng tổng hợp; không dùng các tỷ lệ đó làm minh chứng trước ban giám khảo.

Nghiên cứu Thang và cộng sự (2022) trên 1.788 sinh viên ngoại ngữ báo cáo tỷ lệ triệu chứng trầm cảm, lo âu, stress nặng lần lượt 21,1%, 35,0%, 16,3%. Chỉ dùng để chứng minh vấn đề trong quần thể nghiên cứu; không nói 35% sinh viên cả nước bị rối loạn lo âu. Nguồn: [bài nghiên cứu](https://pubmed.ncbi.nlm.nih.gov/35712280/).

Nghiên cứu Do và cộng sự (2020) trên 1.200 công nhân tại bốn tỉnh ghi nhận 30,5% sàng lọc trầm cảm dương tính. Đây là số liệu lịch sử, không phải khảo sát công nhân Hưng Yên 2026. Nguồn: [bài nghiên cứu](https://pmc.ncbi.nlm.nih.gov/articles/PMC7216084/).

Niên giám Hà Nội 2024 ghi 783.750 sinh viên đại học, gồm 641.890 công lập và 141.860 ngoài công lập. Chỉ dùng làm mốc quy mô vùng có thể mở rộng, không phải số khách hàng hoặc số người đủ điều kiện dùng AnMi. Nguồn: [Niên giám, trang 675](https://thongkehanoi.nso.gov.vn/storage/manager/niengiam_tk/tv3mFL0-3bd210f5-e5f4-4ff2-8adf-0a4daca934dc/Niengiamthongkehanoi2024/files/basic-html/page675.html).

Mốc 87.000 lao động/26 KCN trong thuyết minh chưa được xác minh cùng kỳ và cùng ranh giới hành chính ở đợt này, nên không dùng làm số thị trường hiện hành trên slide. Không cộng dữ liệu trước và sau thay đổi địa giới khi chưa đối chiếu.

## 2. Hệ sinh thái kết nối như thế nào?

Web và thiết bị MYHealth là cửa vào; app/đồng hồ là lộ trình. Chúng dùng chung tài khoản, quyền dữ liệu, API và lõi điều phối. MYHealth phụ trách thu/phát và hiển thị, AI xử lý trên máy chủ. Trong luồng giọng nói có STT chuyển tiếng nói thành chữ và TTS đọc phản hồi. Đồng hồ chỉ cung cấp tín hiệu phụ khi được đồng ý, không tự chẩn đoán.

Lõi xử lý theo thuyết minh: giảm thông tin nhận diện → phân tầng nguy cơ → appraisal/CARE → CogRAG truy hồi ngữ nghĩa, nhận thức và CBT → sinh phản hồi → kiểm tra đầu ra. Nếu cần hỗ trợ khẩn/can thiệp chuyên môn, ưu tiên hướng dẫn tìm người thật và theo dõi trạng thái tiếp nhận; không hứa giao diện hiển thị liên hệ nghĩa là đã có chuyên gia trả lời.

Bộ nhớ lưu theo quyền và thời hạn. Kho vector phục vụ truy hồi khác với kho định danh/giao dịch. Nhà trường/doanh nghiệp chỉ nhận báo cáo tổng hợp đủ nhóm; vai trò chuyên gia nhận ca có quyền khác với người mua hợp đồng. Chưa coi bốn kênh đã tích hợp hoàn chỉnh. Tài liệu rà soát web còn nêu lỗi cần xử lý trước dữ liệu thật.

## 3. Mô hình kinh doanh khai thác từ thuyết minh

Nguồn thu chủ đạo: B2B2C, tổ chức mua suất truy cập theo năm; cá nhân cơ bản miễn phí. Phân khúc thử nghiệm tập trung là sinh viên trưởng thành; công nhân là phân khúc mở rộng phù hợp hồ sơ. Với tổ chức cần xác định người dùng, người ủng hộ, người giữ ngân sách, CNTT/pháp chế và người ký là các vai trò khác nhau.

| Nguồn thu trong hồ sơ | Giá dự kiến | Cách dùng trong dự báo |
|---|---:|---|
| Tổ chức | 12.000–15.000đ/suất/tháng | Cơ sở dùng bình quân 14.000đ, cần kiểm chứng cơ cấu hợp đồng |
| Cá nhân nâng cao | 39.000đ/tháng | Chưa tính vào cơ sở để tránh cộng doanh thu chưa kiểm chứng |
| Thiết bị | Bán khoảng 3 triệu hoặc thuê 300.000đ/tháng | Theo dõi riêng, chưa tính doanh thu cơ sở |
| Đặt lịch chuyên gia | 10% giá buổi theo hồ sơ | Chưa tính; cần hợp đồng và nguyên tắc minh bạch |
| Hướng dẫn/kết nối khẩn cấp | Miễn phí theo hồ sơ | Không thu phí theo ca nguy cơ |

Một hợp đồng 1.000 suất ở giá bình quân 14.000đ/tháng tương đương 168 triệu đồng/năm. Suất tính phí phải được định nghĩa trong hợp đồng; không nhầm với người hoạt động. Nếu bên mua chỉ cấp ngân sách 9–10 tháng/năm học, phải tính lại doanh thu; không mặc nhiên thu đủ 12 tháng.

10 tổ chức × 1.000 suất chỉ là mục tiêu tiếp cận từ dưới lên. Chưa có danh sách khách đủ điều kiện/ngân sách, nên không gọi đó là TAM hoặc thị trường đã chiếm được. Không lấy tỷ lệ trầm cảm nhân dân số rồi nhân đơn giá để tuyên bố doanh thu.

Tham chiếu Headspace cho thấy gói phổ thông và gói sinh viên có điều kiện khác nhau; AnMi không được tự tuyên bố rẻ nhất hoặc thay thế tương đương. Giá trị muốn kiểm chứng: tiếng Việt, hành trình sàng lọc–tự chăm sóc–tìm hỗ trợ và triển khai qua tổ chức. Nguồn giá có trong Excel và Notes.

## 4. Giá thiết bị và danh mục linh kiện

Người dùng xác nhận mẫu **“Quỷ nhỏ thông thái / Monter Desk AI”** qua [liên kết sản phẩm](https://shopee.vn/product/280566046/44719511159) và hai ảnh gửi trong hội thoại. Quan sát được thân trắng có sừng, khung mặt tím, màn hình chữ nhật. Mẫu này khác thiết bị màn tròn trong hình MYHealth của hồ sơ; không dùng ảnh, giá hoặc thông số EchoEar làm thông số của mẫu đang dùng.

Slide dùng hình khối minh họa kiểu dáng theo ảnh, không phải ảnh kỹ thuật hay hình tháo máy. Ảnh không cho biết chip, RAM/Flash, loại màn hình, độ phân giải, số micro, công suất loa, nguồn/pin, khả năng nạp firmware hoặc kết nối API. Các mục này được đưa vào danh sách xác minh, không tự gán thông số.

Ngân sách quay về đúng thuyết minh gốc: **20 triệu cho 10 thiết bị**, tương đương **hạn mức 2 triệu/bộ**; cộng **10 triệu** điện thoại/đồng hồ kiểm thử thành **30 triệu thiết bị năm đầu**. Dự phòng trở về **26 triệu**, tổng năm đầu vẫn **260 triệu**. Đây là hạn mức kế hoạch, KHÔNG phải giá mua hoặc giá thị trường. Chi phí thiết bị thực tế chưa đủ đầu vào nên Excel hiển thị “Chưa đủ đầu vào”; không dùng số không thay cho khoản chưa biết.

Trong BOM, giá đúng bộ, nguồn và cáp đang để trống. Các khoản cấu hình, vận chuyển, dự phòng là dự trù, chỉ dùng khi cần và nằm trong hạn mức chung. Nếu mua bộ đầy đủ thì không cộng lại bo, màn hình, micro, loa, nguồn/pin và vỏ. Khi có hóa đơn hoặc giá biến thể, nhập đúng giá và đối chiếu lại ngân sách; nếu vượt thì điều chỉnh có giải thích.

Kết quả 84/84 trong hồ sơ thuộc MYHealth, chưa được xác nhận là chạy trên mẫu Quỷ nhỏ. Khả năng tích hợp AnMi với đúng thiết bị cần được kiểm tra trước khi trình bày là sản phẩm đã hoạt động. Kiến trúc đích vẫn là thiết bị làm kênh tương tác, lõi AI chạy trên máy chủ; đó là thiết kế cần chứng minh khả thi trên bo mạch/firmware thực tế.

## 5. Kế hoạch tài chính và các giới hạn cần hiểu

| Khoản cố định dự trù | Năm 2 | Năm 3 |
|---|---:|---:|
| Nhân sự | 330 | 420 |
| Chuyên môn/cố vấn | 96 | 120 |
| Bán hàng/triển khai | 72 | 90 |
| Hạ tầng nền | 36 | 48 |
| Pháp lý/kế toán/bảo mật | 36 | 42 |
| **Tổng triệu đồng/năm** | **570** | **720** |

Đây là ngân sách giới hạn, chưa phải báo giá nhân sự thị trường cho đủ 5 thành viên. Năm đầu chưa tính lương sáng lập theo hồ sơ. Chuyên môn là cố vấn/giám sát định mức, chưa bao gồm mọi buổi tư vấn người dùng hoặc trực chuyên môn 24/7.

Biến phí cơ sở 5.000đ/suất/tháng được xây từ mốc nghiên cứu và dự phòng: CogRAG 40 lượt khoảng 422đ; CARE đầy đủ 3 lần khoảng 2.496đ; EviOCEAN 1 lần khoảng 1.196đ; còn khoảng 886đ cho giọng nói và chi phát sinh. Đây là hạn mức cần đo lại, không phải chi phí API hiện hành đã bảo đảm. Safety, retry, lưu trữ và toàn bộ tải miễn phí phải được cộng khi đo giá thành thực.

Lãi đóng góp = giá − biến phí = 9.000đ/suất/tháng, tương đương 64,3%. Đây chưa là lãi ròng. Năm 3, 8.000 suất tạo doanh thu 1.344 triệu, trừ biến phí 480 triệu và cố định 720 triệu còn 144 triệu trước thuế; sau thuế giả định 20% còn 115,2 triệu.

Hoàn vốn cơ sở khoảng 3,94 năm từ 10/2026, gần cuối năm 4. Hòa vốn vận hành năm 3 cần khoảng 6.667 suất. Dòng tiền lũy kế âm tối đa 506 triệu ở cuối năm 2, nên ngoài 260 triệu năm đầu còn cần ít nhất 246 triệu bổ sung; ví dụ kế hoạch gọi thêm 300 triệu gồm khoản đệm 54 triệu. Kế hoạch gọi 500 triệu năm 2 trong hồ sơ gốc vẫn có thể được xem xét theo phạm vi mở rộng, nhưng không ghi số gọi vốn thành doanh thu.

Dòng tiền giản lược coi thu/chi trong năm và chưa có vốn lưu động, khấu hao, đầu tư mới hoặc chi phí vốn; thuế 20% là giả định, chưa bù lỗ và chưa kết luận thuế áp dụng. Thâm hụt trong năm có thể lớn hơn số cuối năm nếu bên mua trả chậm.

Rủi ro cần trình bày: số suất thấp hơn 30% khiến chưa hoàn vốn sau 5 năm. Nếu biến phí lên 8.000đ, biên đóng góp xuống 42,9%; nếu giá thực bán giảm về 12.000đ, phải dùng kịch bản giá thấp riêng, không dùng thời gian hoàn vốn của giá 14.000đ. Các sheet độ nhạy đã tính các trường hợp này.

## 6. Marketing và bán hàng

Kênh người mua: giới thiệu qua trường, phòng công tác SV, đơn vị tư vấn, HR/công đoàn; demo với người có ngân sách. Kênh người dùng: Đoàn–Hội, workshop, QR tại ký túc xá; thông điệp dễ mở lời và quyền riêng tư đúng thực tế. Không quảng cáo bằng suy đoán bệnh của một cá nhân.

Phễu mục tiêu trong giai đoạn kiểm chứng/thí điểm năm đầu: 10 bên mua phỏng vấn → 6 demo phù hợp → 2 đề xuất thí điểm → 1 hợp đồng. Đây là mục tiêu, chưa phải thành tích. Ngân sách 28 triệu gồm tiếp cận 10, nội dung 4, workshop 9, đo lường 5; đã nằm trong 260 triệu nên không cộng lại.

Nếu một khách ký được gán toàn ngân sách 28 triệu, chi thu hút minh họa là 28 triệu/khách. Với 1.000 suất và lãi đóng góp 9 triệu/tháng, khoảng 3,1 tháng đóng góp mới bù khoản đó. Đây không phải hoàn vốn dự án và chưa phải CAC thực tế. Chưa có dữ liệu gia hạn thì chưa tuyên bố LTV đáng tin.

## 7. Khảo sát thực và dữ liệu mô phỏng

Trong Excel chính có mẫu **200 phản hồi người dùng** và **10 phỏng vấn bên mua** đang trống. Không yêu cầu tên, số điện thoại hay bệnh sử; chỉ hỏi nhu cầu tiếp cận hỗ trợ, rào cản, kênh, tính năng và mức tin tưởng riêng tư. Người tham gia tự nguyện, từ 18 tuổi, có quyền bỏ qua. Không coi khảo sát kinh doanh là đánh giá sức khỏe tâm thần.

Phỏng vấn bên mua cần hỏi: vấn đề hiện tại được giải quyết ra sao; ai giữ ngân sách; bao nhiêu suất có thể cấp; giá 12k/14k/15k với cùng quyền lợi có thể được duyệt không; mua theo 12 tháng hay năm học; kỳ phê duyệt, kỳ trả tiền; yêu cầu CNTT/pháp lý; có sẵn sàng thử có phí không. Thư quan tâm, đồng ý demo và hợp đồng trả phí là ba mức bằng chứng khác nhau.

Mẫu thuận tiện 200 người không đại diện toàn bộ sinh viên/công nhân Việt Nam; 10 bên mua là nghiên cứu định tính nhỏ. Ghi thời gian, cách tuyển, số mời và số trả lời hợp lệ khi thực hiện thật. Dùng nhóm sinh viên và công nhân tách biệt khi phân tích.

File **MO_PHONG_200_phan_hoi_KHONG_PHAI_KHAO_SAT.xlsx** chỉ chứa kịch bản sinh ngẫu nhiên có seed để thử công thức. Mọi tỷ lệ trong đó là hệ quả trọng số tự chọn. Không đưa các tỷ lệ đó lên slide như khảo sát đã thực hiện; bộ pitch vẫn dùng nghiên cứu công bố và chỉ tiêu thí điểm.

## 8. Kế hoạch triển khai

11–12/2026: kiểm chứng nhu cầu, người giữ ngân sách, chuyên môn và quyền dữ liệu. 01–03/2027: hoàn thiện web/pipeline, kiểm thử tiếng Việt, quyền và diễn tập tiếp nhận. 04–09/2027: đề xuất 1–2 đơn vị thí điểm, theo dõi đủ 8 tuần, đo sử dụng, chi phí và chất lượng; sau đó đề xuất hợp đồng. Từ 10/2027: mở rộng có điều kiện, phù hợp hồ sơ thuyết minh.

Các KPI từ hồ sơ được chuyển thành mục tiêu đo được: hoàn tất sàng lọc ≥70% trong nhóm đồng ý tham gia; còn hoạt động tuần 4 ≥30% trên người đã kích hoạt. Định nghĩa hoạt động trước khi đo. Hiển thị liên hệ hỗ trợ trong một phút chỉ là chỉ số giao diện; cần theo dõi riêng gửi yêu cầu, xác nhận tiếp nhận và thời gian người thật trả lời. Không dùng “không thấy sự cố” trong mẫu nhỏ để khẳng định đã an toàn lâm sàng.

Đội ngũ theo hồ sơ: Lê Dương Hiếu điều phối/thị trường; Phạm Thị Linh Chi AI; Vũ Đăng Khiêm web/máy chủ; Hoàng Hải Đăng thiết bị; Phạm Đình Phúc dữ liệu/đánh giá. Cần bổ sung cố vấn tâm lý, đối tác tiếp nhận và tư vấn quản trị dữ liệu phù hợp.

## Danh mục nguồn kiểm tra

'''
memo+='\n\n'.join(f'- **{name}**: [{url}]({url}) — {desc}' for name,url,desc in sources)
(P/'Co_so_kinh_doanh_va_nguon_v2.md').write_text(memo,encoding='utf-8')
print('Supporting memo, labeled simulation, and source ledger written.')
