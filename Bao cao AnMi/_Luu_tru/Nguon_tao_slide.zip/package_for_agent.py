from pathlib import Path
import zipfile,json
P=Path(__file__).resolve().parent
ROOT=P.parent
readme='''# ĐỌC TRƯỚC — BỘ TÀI LIỆU THIẾT KẾ ANMI

Làm theo `01_PROMPT.md`. Mục tiêu: thiết kế hoàn chỉnh 10 slide / 5 phút, xuất PPTX chỉnh sửa được và PDF.

## Thứ tự đọc
1. Prompt và thuyết minh trong `02_HO_SO_GOC/`.
2. Excel và bản giải thích trong `03_KINH_DOANH_VA_NGUON/`.
3. Bản slide tham khảo và speaker notes trong `04_SLIDE_HIEN_TAI/`.
4. Paper và hình pipeline/giao diện trong các thư mục còn lại.

## Thiết bị hiện tại
Người dùng xác nhận mẫu Quỷ nhỏ thông thái / Monter Desk AI: thân trắng có sừng, khung mặt tím, màn hình chữ nhật. Hai ảnh phải được đính kèm cùng cuộc giao việc hoặc đặt vào `08_ANH_QUY_NHO_CAN_BO_SUNG/`.

Ảnh EchoEar/MYHealth màn hình tròn trong tài liệu gốc là tư liệu lịch sử của mẫu khác. KHÔNG thay thế cho ảnh Quỷ nhỏ, KHÔNG áp giá/thông số hay 84/84 kiểm thử sang mẫu Quỷ nhỏ.

2 triệu đồng/bộ là hạn mức theo thuyết minh, chưa phải giá thị trường. Dự báo 3,94 năm hoàn vốn là mô hình có giả định, không phải thành tích đã đạt. Các sheet khảo sát còn trống. Không có dữ liệu khảo sát người dùng thật trong bộ giao việc này.

## Tư liệu gốc
Các tài liệu gốc được giữ nguyên, có thể chứa trạng thái cũ hoặc dự báo đã được điều chỉnh. Xem thứ tự ưu tiên trong prompt. Các số liệu cần có nguồn, kỳ dữ liệu và phạm vi.
'''
image_note='''Đặt 2 ảnh người dùng đã gửi trong hội thoại vào thư mục này hoặc đính kèm trực tiếp cho agent.
Ảnh 1: Quỷ nhỏ thân trắng/mặt tím trên bàn, chữ “thông minh - vui tính”.
Ảnh 2: cùng mẫu trên máy tính, chữ “Quỷ nhỏ thông thái” và “Monter Desk AI”.
Chưa có bản ảnh đính kèm được lưu thành tệp trong workspace, nên ZIP không chứa hai ảnh gốc này.
Không dùng ảnh EchoEar/MYHealth màn hình tròn để thay.
'''
files=[(P/'PROMPT_CHO_AGENT_THIET_KE_SLIDE.md','01_PROMPT.md'),(P/'HUONG_DAN_GUI_AGENT.md','HUONG_DAN_GUI_AGENT.md')]
for src in sorted((ROOT/'Tài liệu').glob('*.docx')):files.append((src,'02_HO_SO_GOC/'+src.name))
files.append((ROOT/'README.txt','02_HO_SO_GOC/README_HO_SO.txt'))
for name in ['AnMi_Mo_hinh_tai_chinh.xlsx','Co_so_kinh_doanh_va_nguon_v2.pdf','Co_so_kinh_doanh_va_nguon_v2.md','sources_v2.json']:
    files.append((P/name,'03_KINH_DOANH_VA_NGUON/'+name))
for name in ['AnMi_Pitch_10_slide.pptx','AnMi_Pitch_10_slide.pdf','Tong_quan_10_slide.jpg','Loi_thuyet_trinh_va_hoi_dap.md']:
    files.append((P/name,'04_SLIDE_HIEN_TAI/'+name))
for src in sorted((ROOT/'Paper').glob('*.pdf')):files.append((src,'05_PAPER/'+src.name))
for src in sorted((ROOT/'Hinh anh CogAI').glob('*.png')):
    legacy=src.name.startswith('Hinh 4 ') or src.name.startswith('Hinh 5 ')
    files.append((src,('07_MAU_CU_MYHEALTH_CHI_THAM_KHAO/' if legacy else '06_PIPELINE_VA_HINH_HO_SO/')+src.name))
for name in ['04-tro-chuyen.png','09-ket-qua-phq9.png','16-chuyen-gia.png','17-quan-tri-tong-quan.png']:
    src=ROOT/'cogai/docs/huong-dan-demo/assets'/name
    if src.exists():files.append((src,'06_PIPELINE_VA_HINH_HO_SO/DEMO_DU_LIEU_TONG_HOP/'+name))
assert all(p.exists() for p,_ in files)
out=P/'AnMi_Goi_giao_agent_thiet_ke.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    z.writestr('00_DOC_TRUOC.md',readme)
    z.writestr('08_ANH_QUY_NHO_CAN_BO_SUNG/DAT_HAI_ANH_NGUOI_DUNG_VAO_DAY.txt',image_note)
    z.writestr('07_MAU_CU_MYHEALTH_CHI_THAM_KHAO/LUU_Y.txt','Ảnh nguyên mẫu cũ trong hồ sơ. Không phải mẫu Quỷ nhỏ người dùng đang dùng; không chuyển giá, cấu hình hoặc kết quả kiểm thử sang mẫu mới.')
    for src,dst in files:z.write(src,dst)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert not any('MO_PHONG' in n or 'shop_login' in n or 'shop-public' in n or '_lib' in n for n in z.namelist())
    print(json.dumps({'zip':out.name,'files':len(z.namelist()),'bytes':out.stat().st_size,'additional_attachments':'2 anh Quy nho do nguoi dung cung cap'}))
