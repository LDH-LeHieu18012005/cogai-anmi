# Executed within build_pitch.py, sharing the workbook and formatting helpers.
fc=wb.add_worksheet('Chi phi co dinh');bom=wb.add_worksheet('BOM thiet bi');vc=wb.add_worksheet('Bien phi');mk=wb.add_worksheet('Marketing');market=wb.add_worksheet('Thi truong');sv=wb.add_worksheet('Khao sat nguoi dung');buyer=wb.add_worksheet('Phong van ben mua');track=wb.add_worksheet('Ke hoach trien khai')
cashfmt=wb.add_format({'num_format':'#,##0;[Red](#,##0)'});blue=wb.add_format({'font_color':'blue','num_format':'#,##0.00'});linkfmt=wb.add_format({'font_color':'#006B6A','underline':1,'text_wrap':True})

fc.set_column('A:A',39);fc.set_column('B:F',18);fc.set_column('G:G',85)
fc.write_row(0,0,['Khoản cố định','N2/tháng','N2/năm','N3/tháng','N3/năm','Đơn vị','Căn cứ / phạm vi'],head)
costs=[('Nhân sự',27.5,35,'2 nhân sự kỹ thuật + vận hành bán thời gian. Đây là hạn mức chi phí toàn phần, chưa là báo giá lương; chưa gồm lương thị trường của đủ 5 sáng lập.'),('Chuyên môn / cố vấn',8,10,'Cố vấn nền và giám sát trong định mức; không bao gồm mọi buổi tư vấn cá nhân hoặc trực chuyên môn 24/7.'),('Bán hàng / triển khai',6,7.5,'Gồm marketing, đi lại và triển khai; năm 1 dùng riêng khoản 28 triệu. Không cộng lại CAC như khoản chi mới.'),('Hạ tầng nền',3,4,'Máy chủ nền, dữ liệu, sao lưu, giám sát. Phần tăng theo mức dùng thuộc biến phí.'),('Pháp lý / kế toán / bảo mật',3,3.5,'Ngân sách duy trì quản trị; chưa có hợp đồng dịch vụ cụ thể.')]
for r,(name,m2,m3,desc) in enumerate(costs,1):
    fc.write(r,0,name);fc.write(r,1,m2,blue);fc.write_formula(r,2,f'=B{r+1}*12',num,m2*12);fc.write(r,3,m3,blue);fc.write_formula(r,4,f'=D{r+1}*12',num,m3*12);fc.write(r,5,'Triệu đồng');fc.write(r,6,desc,wrap);fc.set_row(r,65)
fc.write(6,0,'Tổng',head)
for c,col,v in [(1,'B',47.5),(2,'C',570),(3,'D',60),(4,'E',720)]:fc.write_formula(6,c,f'=SUM({col}2:{col}6)',num,v)
fc.merge_range('A10:G12','Ngân sách cố định tăng theo nấc khi mở rộng; không bất biến mọi quy mô. N2/N3 tính theo năm hoạt động, từ tháng 10. Năm 1: 260 triệu là tổng chi khởi tạo và vận hành, không phải tất cả là tài sản/chi phí cố định. N4/N5 là tổng giả định cần lập dự toán sau thí điểm.',wrap)
fc.write_row(14,0,['Tham chiếu hạ tầng','Giá tháng (đ)','Giá trả năm (đ)','URL'],head)
fc.write(15,0,'Cloud VPS 50 / 4vCPU 4GB');fc.write(15,1,639000,cashfmt);fc.write(15,2,6134400,cashfmt);fc.write_url(15,3,'https://www.tnd.vn/pricing/',linkfmt,'Bảng giá nhà cung cấp')
fc.merge_range('A18:G20','Mốc giá một máy ảo dùng đối chiếu, chưa chứng minh cấu hình này đủ tải hoặc phù hợp xử lý dữ liệu sức khỏe. Ngân sách 3–4 triệu/tháng còn phải bao gồm backup, quan sát, bảo mật, lưu trữ, dự phòng. VAT và giá hợp đồng cần xác nhận. Không xem 639.000đ là toàn bộ giá thành nền tảng.',wrap)
f.write_formula(5,2,"='Chi phi co dinh'!C7",num,570);f.write_formula(5,3,"='Chi phi co dinh'!E7",num,720)
f.write(27,0,'Thâm hụt lũy kế tối đa');f.write_formula(27,1,'=MAX(0,-MIN(B12:F12))',num,506)
f.write(28,0,'Vốn bổ sung tối thiểu sau năm 1');f.write_formula(28,1,"=MAX(0,B28-'Gia dinh'!B5)",num,246)
f.write(29,0,'Đề xuất đệm vốn bổ sung (triệu)');f.write(29,1,54,inp)
f.write(30,0,'Mục tiêu huy động bổ sung N2');f.write_formula(30,1,'=B29+B30',num,300)
f.write_formula(15,1,'=IFERROR(IF(B12>=0,0,IF(C12>=0,1-B12/C11,IF(D12>=0,2-C12/D11,IF(E12>=0,3-D12/E11,IF(F12>=0,4-E12/F11,"Chưa hoàn vốn trong 5 năm"))))),"Kiểm tra dòng tiền")',num,3+390.8/416)
f.merge_range('A33:F35','506 triệu chỉ là thâm hụt cực đại theo tổng cuối năm. Hợp đồng trả chậm hoặc trả theo kỳ, mùa vụ, chi phí vượt dự toán có thể làm nhu cầu vốn trong năm cao hơn. Vốn góp/tài trợ/gọi vốn là dòng tài trợ, không phải doanh thu. Năm 2 đề xuất huy động 300 triệu gồm tối thiểu 246 + đệm 54; chưa xác nhận nguồn huy động.',wrap)

bom.set_column('A:A',52);bom.set_column('B:D',17);bom.set_column('E:E',45);bom.set_column('F:F',75)
bom.write_row(0,0,['Khoản mua cho 1 thiết bị','SL','Đơn giá (đ)','Thành tiền (đ)','Trạng thái giá','Nguồn / lưu ý'],head)
bomrows=[('Bộ Quỷ nhỏ thông thái / Monter Desk AI',1,None,'Chưa có giá đúng mẫu','Kiểu dáng xác nhận từ 2 ảnh người dùng. Chưa đọc được giá mua, chip, RAM/Flash, khả năng nạp firmware/API.'),('Nguồn/sạc phù hợp bộ thực tế',1,None,'Chờ xác nhận phụ kiện','Không áp thông số 5V/2A nếu chưa đọc nhãn nguồn của đúng bộ. Nếu đã kèm, không mua và không tính lại.'),('Cáp kết nối/nguồn phù hợp',1,None,'Chờ xác nhận phụ kiện','Không tự khẳng định USB-C từ ảnh chính diện; kiểm tra cổng và phụ kiện đi kèm.'),('Cấu hình, nạp phần mềm, kiểm tra',1,100000,'Dự trù riêng, chưa báo giá','Chỉ thực hiện sau khi xác nhận phần cứng cho phép tích hợp; không phải giá linh kiện.'),('Vận chuyển và phát sinh',1,100000,'Dự trù riêng','Chờ báo giá/thuế/phí hợp lệ; chưa phải chi thực tế.'),('Dự phòng thiết bị',1,100000,'Dự trù riêng','Phải nằm trong hạn mức 2 triệu/bộ hoặc duyệt lại ngân sách nếu vượt.')]
for r,(name,q,v,status,desc) in enumerate(bomrows,1):
    bom.write(r,0,name);bom.write(r,1,q,inp)
    if v is not None:bom.write(r,2,v,inp)
    bom.write_formula(r,3,f'=IF(ISNUMBER(C{r+1}),B{r+1}*C{r+1},"Chưa có giá")',cashfmt,q*v if v is not None else 'Chưa có giá')
    bom.write(r,4,status,wrap);bom.write(r,5,desc,wrap);bom.set_row(r,65)
bom.write(7,0,'Hạn mức kế hoạch / thiết bị, KHÔNG phải giá thành',head);bom.write(7,3,2000000,inp)
bom.write(8,0,'Số thiết bị thí điểm');bom.write(8,1,10,inp);bom.write_formula(8,3,'=D8*B9',cashfmt,20000000)
bom.write(9,0,'Điện thoại / đồng hồ kiểm thử');bom.write(9,3,10000000,inp)
bom.write(10,0,'Ngân sách thiết bị năm 1 theo thuyết minh');bom.write_formula(10,3,'=D9+D10',cashfmt,30000000)
bom.write(11,0,'Tổng chi phí khi đủ giá từng khoản');bom.write_formula(11,3,'=IF(COUNT(C2:C7)<6,"Chưa đủ đầu vào",SUM(D2:D7))',cashfmt,'Chưa đủ đầu vào')
a.write_formula(16,1,"='BOM thiet bi'!D11/1000000",num,30)
bom.write_row(13,0,['Bộ phận cần kiểm tra đúng mẫu','Số lượng','Giá riêng','Tính trùng?','Vai trò dự kiến / quan sát','Trạng thái'],head)
parts=[('Bo điều khiển / kết nối',None,'Chờ BOM','Không cộng lại nếu đã trong bộ','Kết nối với phần mềm AnMi','Chưa xác minh loại chip, bộ nhớ, firmware hoặc API.'),('Màn hình chữ nhật',1,'Chờ BOM','Không cộng lại nếu đã trong bộ','Hiển thị biểu cảm','Quan sát thấy từ ảnh; chưa xác nhận công nghệ, kích thước hay độ phân giải.'),('Micro',None,'Chờ BOM','Không cộng lại nếu đã trong bộ','Thu lời nói nếu bộ có hỗ trợ','Chưa xác minh linh kiện hoặc số lượng.'),('Loa / mạch âm thanh',None,'Chờ BOM','Không cộng lại nếu đã trong bộ','Phát tiếng nếu bộ có hỗ trợ','Không áp cấu hình loa 3W hay micro kép của EchoEar.'),('Nguồn / pin / mạch sạc',None,'Chờ BOM','Theo bộ thực mua','Cấp nguồn','Cần ảnh nhãn nguồn, cổng và danh mục phụ kiện.'),('Vỏ thân trắng, mặt tím',1,'Chờ BOM','Đã nằm trong giá nếu mua bộ','Kiểu dáng thiết bị','Quan sát từ ảnh; không suy ra vật liệu, giá khuôn hay chi phí in 3D.')]
for r,row in enumerate(parts,14):
    for c,value in enumerate(row):
        if value is not None:bom.write(r,c,value,wrap)
    bom.set_row(r,64)
bom.merge_range('A23:F25','Ảnh người dùng xác nhận đúng mẫu Quỷ nhỏ thông thái / Monter Desk AI. Không dùng giá EchoEar hoặc linh kiện màn hình tròn để định giá mẫu này. Hạn mức 2 triệu/bộ lấy từ 20 triệu/10 thiết bị trong thuyết minh, KHÔNG được coi là giá thị trường. Khi có giá đúng mẫu, nhập từng khoản và so sánh với hạn mức. Nếu vượt, điều chỉnh dự phòng/tổng ngân sách minh bạch.',wrap)
bom.merge_range('A28:F30','Tên MYHealth và kết quả 84/84 thuộc nguyên mẫu mô tả trong hồ sơ, không tự động trở thành kết quả kiểm thử của mẫu Quỷ nhỏ. Cần kiểm tra khả năng tích hợp và chạy lại các ca liên quan trên phần cứng đúng mẫu trước khi tuyên bố đã hoạt động.',wrap)

vc.set_column('A:A',42);vc.set_column('B:D',20);vc.set_column('E:E',95)
vc.write_row(0,0,['Khoản tham chiếu / suất / tháng','Số lần','USD/lần','VNĐ','Căn cứ / giới hạn'],head)
costitems=[('CogRAG',40,.000406,422.24,'Mốc chi phí trong Paper; không phải báo giá API hiện tại và không bao hết nguy cơ/kiểm đầu ra.'),('CARE đầy đủ',3,.032,2496,'Mốc chi phí nghiên cứu một cấu hình. Không chạy đầy đủ mỗi tin; mốc khác theo mô hình/dữ liệu.'),('EviOCEAN',1,.046,1196,'Mốc GPT-4o trong bài báo; chưa chứng minh là cấu hình tối ưu cho MVP. Có thể tắt khi chưa đủ bằng chứng.')]
for r,(name,q,v,total,desc) in enumerate(costitems,1):
    vc.write(r,0,name);vc.write(r,1,q,inp);vc.write(r,2,v,blue);vc.write_formula(r,3,f'=B{r+1}*C{r+1}*\'Gia dinh\'!$B$7',num,total);vc.write(r,4,desc,wrap);vc.set_row(r,62)
vc.write(4,0,'Dư địa voice / phát sinh / hạ tầng');vc.write_formula(4,3,"='Gia dinh'!B3-SUM(D2:D4)",num,885.76);vc.write(4,4,'Khoản ngân sách còn lại, chưa phải đo đạc. Phải đo STT/TTS, safety, retry, lưu trữ và tải miễn phí trước khi chốt giá.',wrap);vc.set_row(4,60)
vc.write(5,0,'Tổng biến phí mục tiêu');vc.write_formula(5,3,'=SUM(D2:D5)',num,5000)
vc.write(7,0,'Mức dùng cao: biến phí/suất/tháng');vc.write_formula(7,3,"='Gia dinh'!B8",num,8000)
vc.merge_range('A11:E14','Đây là phép xây dựng hạn mức chi phí từ mốc nghiên cứu và dự phòng. Thực tế có thể cao hơn đáng kể. Chi phí người dùng miễn phí chưa đo; cần cộng mọi chi phục vụ miễn phí vào tổng biến phí trên số suất trả phí. Không cho rằng 40 lượt bao phủ mọi người dùng. Không dùng chi phí paper làm cam kết đơn giá vận hành.',wrap)
vc.write(16,0,'Tiêu chí cần đo');vc.write(16,4,'Chi phí/chat; chi phí/suất trả phí (bao tải miễn phí); giọng nói/phút; p95; số retry; chi kiểm nguy cơ; số người chuyên môn cần tiếp nhận.',wrap)

market.set_column('A:A',42);market.set_column('B:B',22);market.set_column('C:C',100)
market.write_row(0,0,['Chỉ tiêu','Giá trị','Phạm vi / ý nghĩa'],head)
market.write_row(1,0,['SV đại học Hà Nội 2024',783750,'Nguồn thống kê chính thức S3; chỉ dùng làm mốc quy mô vùng, không khẳng định tất cả đủ điều kiện hay có nhu cầu mua.'],wrap)
market.write_row(2,0,['Lo âu nặng trong mẫu SV',.35,'S1, n=1.788, một trường, công bố 2022. Không nhân với tổng SV để suy doanh thu.'],wrap)
market.write_row(3,0,['Sàng lọc trầm cảm mẫu công nhân',.305,'S2, n=1.200 tại 4 tỉnh, công bố 2020. Không dùng như tỷ lệ 2026 của Hưng Yên.'],wrap)
market.write(5,0,'Tổ chức mục tiêu tiếp cận');market.write(5,1,10,inp)
market.write(6,0,'Suất mục tiêu/tổ chức');market.write(6,1,1000,inp)
market.write(7,0,'Tổng suất mục tiêu tiếp cận');market.write_formula(7,1,'=B6*B7',cashfmt,10000)
market.write(8,0,'Doanh thu năm nếu bán đủ mục tiêu');market.write_formula(8,1,"=B8*'Gia dinh'!B2*12",cashfmt,1680000000)
market.write(9,0,'Doanh thu này là gì?');market.write(9,2,'Kịch bản từ dưới lên, không phải TAM/SAM đã xác minh. Cần danh sách tài khoản cụ thể, quy mô đủ điều kiện, người mua, ngân sách và lịch mua.',wrap)
market.write(11,0,'Phân khúc ưu tiên');market.write(11,2,'Sinh viên trưởng thành tại trường đại học. Người trả phí: nhà trường. Người quyết định, bộ phận tư vấn, CNTT, pháp chế và người dùng là các bên khác nhau.',wrap)
market.write(12,0,'Phân khúc mở rộng');market.write(12,2,'Công nhân; người mua là doanh nghiệp/công đoàn. Thử ngoài giờ/ca kíp, quyền riêng tư, ngân sách phúc lợi và mức dùng thực tế trước mở rộng.',wrap)
market.write(14,0,'Kế hoạch nghiên cứu sơ cấp');market.write(14,2,'Mục tiêu 200 phản hồi tự nguyện của người dùng từ 18 tuổi + 10 phỏng vấn đơn vị trả phí. Mẫu thuận tiện có phân nhóm năm học/xa nhà/ca kíp; không đại diện xác suất. Mẫu đang trống.',wrap)
market.write(15,0,'Nhu cầu KHÔNG đồng nghĩa sẵn sàng trả');market.write(15,2,'Sinh viên có thể thích dùng miễn phí trong khi trường không có ngân sách. Phải tìm được chủ ngân sách, đường mua và một cam kết thí điểm trả phí; thư quan tâm không được tính là doanh thu.',wrap)
for r in range(1,17):market.set_row(r,58)

mk.set_column('A:A',44);mk.set_column('B:D',23);mk.set_column('E:E',100)
mk.write_row(0,0,['Hoạt động / giai đoạn năm đầu','Ngân sách triệu','Mục tiêu','Thực tế','Ghi chú'],head)
for r,row in enumerate([('Tiếp cận bên mua',10,10,'','Phòng công tác SV/HR/công đoàn; phỏng vấn và demo đúng người có quyền mua.'),('Nội dung / landing / QR',4,'Chốt thông điệp','','Chỉ dùng lời giới thiệu đúng năng lực; không tuyên bố ngăn tự sát hay điều trị.'),('Workshop / kích hoạt',9,2,'','Mục tiêu 2 đề xuất thí điểm; cần đồng ý trước, không phải đối tác đã có.'),('Đo lường / khảo sát',5,200,'','200 phản hồi người dùng tự nguyện mục tiêu; không phải phản hồi đã thu.')],1):mk.write_row(r,0,row,wrap);mk.set_row(r,65)
mk.write(5,0,'Tổng ngân sách');mk.write_formula(5,1,'=SUM(B2:B5)',num,28)
mk.write_row(8,0,['Phễu mục tiêu','Số mục tiêu','Chuyển đổi giả định','Thực tế','Định nghĩa'],head)
for r,row in enumerate([('Bên mua phỏng vấn',10,None,None,'Có trao đổi với đại diện đơn vị; sau đó xác minh đúng người quyết định.'),('Demo phù hợp',6,.6,None,'Người mua đánh giá phạm vi phù hợp và thống nhất buổi xem sản phẩm.'),('Đề xuất thí điểm',2,2/6,None,'Có phạm vi/chi phí/quy trình; chưa coi là hợp đồng.'),('Hợp đồng trả phí',1,.5,None,'Chỉ ghi khi ký hợp đồng có nghĩa vụ thanh toán.')],9):
    for c,v in enumerate(row):
        if v is not None:mk.write(r,c,v,pct if c==2 else wrap)
    mk.set_row(r,57)
mk.write(14,0,'Chi thu hút minh họa / 1 tổ chức');mk.write_formula(14,1,'=B6/B13',num,28)
mk.write(15,0,'Số suất/hợp đồng minh họa');mk.write(15,1,1000,inp)
mk.write(16,0,'Lãi đóng góp/tháng hợp đồng (triệu)');mk.write_formula(16,1,"=B16*('Gia dinh'!B2-'Gia dinh'!B3)/1000000",num,9)
mk.write(17,0,'Tháng bù chi thu hút minh họa');mk.write_formula(17,1,'=B15/B17',num,28/9)
mk.merge_range('A21:E23','28 triệu/1 khách là phép phân bổ toàn ngân sách năm đầu nếu đạt 1 hợp đồng; chưa phải CAC đo được. Khoảng 3,1 tháng bù chi thu hút chỉ tính lãi đóng góp, không phải hoàn vốn toàn dự án, chưa tính chi triển khai khác hay thời gian chờ trả tiền. Không dùng LTV khi chưa có dữ liệu gia hạn.',wrap)

# Blank instruments: no invented responses, no pre-filled survey findings.
svheaders=['Mã ngẫu nhiên','Đồng ý khảo sát?','Từ 18 tuổi?','Nhóm SV/công nhân','Năm học / ca làm','Xa gia đình?','Nhu cầu tìm hỗ trợ 4 tuần (1–5)','Cản trở lớn nhất','Kênh muốn dùng','Mức tin tưởng riêng tư (1–5)','Tính năng ưu tiên','Sẵn lòng thử AI?','Tần suất dự định','Góp ý không ghi thông tin cá nhân']
sv.write_row(0,0,svheaders,head);sv.set_column('A:F',19);sv.set_column('G:N',30);sv.set_row(0,58)
for r in range(1,201):
    sv.write_blank(r,0,None,wrap)
sv.data_validation('B2:B201',{'validate':'list','source':['Có','Không']});sv.data_validation('C2:C201',{'validate':'list','source':['Có','Không']});sv.data_validation('G2:G201',{'validate':'integer','criteria':'between','minimum':1,'maximum':5});sv.data_validation('J2:J201',{'validate':'integer','criteria':'between','minimum':1,'maximum':5})
sv.autofilter(0,0,200,len(svheaders)-1);sv.freeze_panes(1,1)
sv.write(203,0,'DỮ LIỆU ĐANG TRỐNG — KHÔNG PHẢI KẾT QUẢ KHẢO SÁT',head)
sv.write(205,0,'Số phản hồi đủ điều kiện');sv.write_formula(205,1,'=COUNTIFS(B2:B201,"Có",C2:C201,"Có",G2:G201,">=1",G2:G201,"<=5")',cashfmt,0)
sv.write(206,0,'Tỷ lệ nhu cầu >=4/5 trong mẫu hợp lệ');sv.write_formula(206,1,'=IF(B206=0,"Chưa có dữ liệu",COUNTIFS(B2:B201,"Có",C2:C201,"Có",G2:G201,">=4",G2:G201,"<=5")/B206)',pct,'Chưa có dữ liệu')
sv.merge_range('A210:N212','Không thu tên, số điện thoại, lịch sử hội thoại, chẩn đoán hoặc chi tiết khủng hoảng trong khảo sát kinh doanh này. Dừng nếu không đồng ý hoặc dưới 18 tuổi. Cần lời giới thiệu, mục đích, quyền bỏ qua/xóa theo quy trình đã duyệt. Phân tích tách sinh viên/công nhân; mẫu thuận tiện không được tuyên bố tỷ lệ đại diện hoặc khoảng tin cậy như mẫu ngẫu nhiên.',wrap)
buyerheaders=['Mã tổ chức','Phân khúc','Vai trò người trả lời','Có quyền quyết định?','Vấn đề/quy trình hiện tại','Ai giữ ngân sách?','Suất có thể mua','Ngân sách năm VNĐ','Giá thử VNĐ/suất/tháng','12 tháng hay năm học?','Kỳ phê duyệt / thanh toán','Yêu cầu dữ liệu / bảo mật','Đồng ý thử có phí?','Chứng cứ / bước tiếp','Trạng thái hợp đồng']
buyer.write_row(0,0,buyerheaders,head);buyer.set_column('A:D',24);buyer.set_column('E:O',36);buyer.set_row(0,65)
for r in range(1,11):buyer.write_blank(r,0,None,wrap);buyer.set_row(r,80)
buyer.autofilter(0,0,10,len(buyerheaders)-1);buyer.freeze_panes(1,1)
buyer.merge_range('A14:O16','Mẫu đang trống. Mục tiêu 10 cuộc phỏng vấn định tính. Thử giá 12k/14k/15k với quyền lợi và số suất như nhau, xoay thứ tự để giảm neo giá. Hỏi giá có thể duyệt, nguồn ngân sách, kỳ thanh toán, mùa vụ và điều kiện mua. Ghi câu trả lời nguyên ý. Không tự điền một tổ chức là khách hàng/đối tác. Không gộp ý định thử miễn phí với đồng ý trả phí.',wrap)

track.set_column('A:A',22);track.set_column('B:B',52);track.set_column('C:D',55);track.set_column('E:E',40)
track.write_row(0,0,['Mốc kế hoạch','Công việc','Đầu ra cần có','Điều kiện sang bước tiếp','Phụ trách đề xuất'],head)
for r,row in enumerate([('11–12/2026','Khảo sát 200 người dùng mục tiêu, phỏng vấn 10 bên mua; chốt phân khúc và giá','Tệp phản hồi có nguồn, tổng hợp không có dữ liệu định danh; bản yêu cầu bên mua','Có chủ ngân sách, cố vấn chuyên môn; không suy ý định thành doanh thu','Hiếu / Phúc; cần cố vấn'),('01–03/2027','Hoàn thiện web và pipeline; dữ liệu Việt, quyền đồng ý, an toàn, đo chi phí','Báo cáo kiểm thử chức năng, quyền và chất lượng Việt; diễn tập tiếp nhận','Chuyên gia duyệt phạm vi; xử lý lỗi nghiêm trọng; đối tác và quy trình rõ','Chi / Khiêm / Phúc'),('04–06/2027','Thí điểm có giám sát tại 1–2 đơn vị mục tiêu; thiết bị tối đa 10','Dữ liệu sử dụng theo đồng ý, giữ chân, sự cố, chi phí, phản hồi chuyên gia','Theo dõi đủ 8 tuần; quyết định dừng/sửa nếu không đạt','Hiếu / Đăng; đơn vị tiếp nhận'),('07–09/2027','Tối ưu giá, quy trình; đề xuất hợp đồng trả phí','Có chứng cứ sẵn sàng mua, phạm vi hợp đồng và phương án vận hành','Mở rộng khi có cam kết trả phí, người quay lại và chuyên môn đồng ý','Hiếu; cả nhóm'),('Từ 10/2027','Mở rộng có điều kiện; thử công nhân và đa kênh','Doanh thu, tỷ lệ gia hạn, chi phí/suất, quy trình ứng cứu và thu hồi quyền','Vốn bổ sung, kinh tế đơn vị và đối tác tiếp nhận đáp ứng quy mô','Nhóm + đối tác phù hợp')],1):track.write_row(r,0,row,wrap);track.set_row(r,100)
track.merge_range('A9:E11','KPI đề xuất: hoàn tất sàng lọc >=70% trong nhóm đã đồng ý tham gia; người hoạt động tuần 4 >=30% trên số đã kích hoạt; theo dõi chi phí mọi tải, sự cố và từng trạng thái kết nối. Định nghĩa người hoạt động: có ít nhất 1 hoạt động có ý nghĩa trong 7 ngày (chat/bài tập/sàng lọc/mood). Đây là mục tiêu kinh doanh/thí điểm, không phải ngưỡng chứng minh hiệu quả lâm sàng hoặc an toàn.',wrap)
for sh in [fc,bom,vc,mk,market,track]:sh.freeze_panes(1,1);sh.hide_gridlines(2)

# Keep the downside visible when the final negotiated price reaches the bottom of the proposed range.
sc.write_row(13,0,['Giá chỉ 12.000đ/suất/tháng',1,2,3,4,5],head)
sc.write(14,0,'Lãi sau thuế giả định');sc.write(15,0,'Lũy kế dòng tiền')
sc.write_row(18,0,['Biến phí lên 8.000đ/tháng',1,2,3,4,5],head)
sc.write(19,0,'Lãi sau thuế giả định');sc.write(20,0,'Lũy kế dòng tiền')
lo_cum=hi_cum=0
for i in range(5):
    c=xlsxwriter.utility.xl_col_to_name(i+1);u=users[i]
    lp=u*(12000-5000)*12/1e6-fixed[i];ln=lp-max(0,lp)*.2;lo_cum+=ln
    hp=u*(14000-8000)*12/1e6-fixed[i];hn=hp-max(0,hp)*.2;hi_cum+=hn
    lowformula=f"('Du bao 5 nam'!{c}3*(12000-'Gia dinh'!$B$3)*12/1000000-'Du bao 5 nam'!{c}6)"
    highformula=f"('Du bao 5 nam'!{c}3*('Gia dinh'!$B$2-'Gia dinh'!$B$8)*12/1000000-'Du bao 5 nam'!{c}6)"
    sc.write_formula(14,i+1,f'={lowformula}-MAX(0,{lowformula})*\'Gia dinh\'!$B$4',num,ln)
    sc.write_formula(15,i+1,f'=SUM($B15:{c}15)',num,lo_cum)
    sc.write_formula(19,i+1,f'={highformula}-MAX(0,{highformula})*\'Gia dinh\'!$B$4',num,hn)
    sc.write_formula(20,i+1,f'=SUM($B20:{c}20)',num,hi_cum)
sc.merge_range('A24:F27','Giá 12k là đáy dải trong hồ sơ, không phải mức đã bán. Kịch bản cơ sở 14k phải được bảo vệ bằng cơ cấu hợp đồng/giá thực bán. Nếu đa số hợp đồng hưởng giá 12k, không được dùng kết quả hoàn vốn cơ sở 14k để trình bày. Chỉ tính hợp đồng ký và suất bình quân đủ thời gian thu phí; 12 tháng là giả định cần đối chiếu ngân sách năm học.',wrap)
chart=wb.add_chart({'type':'line'})
chart.add_series({'name':'Lũy kế dòng tiền giản lược','categories':['Du bao 5 nam',0,1,0,5],'values':['Du bao 5 nam',11,1,11,5],'line':{'color':'#00786A','width':3},'marker':{'type':'circle','size':6}})
chart.set_title({'name':'Dòng tiền lũy kế / triệu đồng'});chart.set_legend({'none':True});chart.set_y_axis({'major_gridlines':{'visible':True},'crossing':0});f.insert_chart('A38',chart,{'x_scale':1.45,'y_scale':1.2})
