from pathlib import Path
import sys,json,re,zipfile,xml.etree.ElementTree as E
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P/'_lib'))
from pptx import Presentation
from PIL import Image
r=Presentation(P/'AnMi_Pitch_10_slide.pptx');slides=json.loads((P/'slides.json').read_text(encoding='utf-8'))
assert len(r.slides)==10 and len(slides)==10
assert sum(s['secs'] for s in slides)==300
assert all(s.notes_slide.notes_text_frame.text for s in r.slides)
assert not json.loads((P/'layout-check.json').read_text())
for i,s in enumerate(r.slides,1):
    for shape in s.shapes:
        assert shape.left>=0 and shape.top>=0,(i,shape.name,'negative position')
        assert shape.left+shape.width<=r.slide_width+9144,(i,shape.name,'right overflow')
        assert shape.top+shape.height<=r.slide_height+9144,(i,shape.name,'bottom overflow')
assert len(re.findall(rb'/Type\s*/Page\b',(P/'AnMi_Pitch_10_slide.pdf').read_bytes()))==10
ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
z=zipfile.ZipFile(P/'AnMi_Mo_hinh_tai_chinh.xlsx')
workbook=E.fromstring(z.read('xl/workbook.xml'));names=[s.attrib['name'] for s in workbook.findall('s:sheets/s:sheet',ns)]
assert all(n in names for n in ['BOM thiet bi','Chi phi co dinh','Marketing','Khao sat nguoi dung','Phong van ben mua'])
def cells(sheetidx):
    root=E.fromstring(z.read(f'xl/worksheets/sheet{sheetidx}.xml'))
    return {c.attrib['r']:(c.find('s:v',ns).text if c.find('s:v',ns) is not None else None) for c in root.findall('.//s:c',ns)}
cf=cells(2)
assert [float(cf[c]) for c in ['B10','C10','D10','E10','F10']]==[-260,-246,115.2,416,800]
assert abs(float(cf['B16'])-(3+390.8/416))<1e-8
assert float(cf['B28'])==506 and float(cf['B29'])==246
bom=cells(names.index('BOM thiet bi')+1)
assert float(bom['D8'])==2000000 and float(bom['D11'])==30000000
assert not any(b'#REF!' in z.read(n) or b'#DIV/0!' in z.read(n) for n in z.namelist() if n.endswith('.xml'))
canvas=Image.new('RGB',(1600,2250),'#dce5de')
for i,f in enumerate(sorted((P/'assets').glob('slide-*.png'))):
    im=Image.open(f);im.thumbnail((800,450));canvas.paste(im,((i%2)*800,(i//2)*450))
canvas.save(P/'Tong_quan_10_slide.jpg')
report={'slides':10,'seconds':300,'layout_overflow':0,'workbook_sheets':names,'payback_years':float(cf['B16']),'maximum_funding_gap_million':506,'hardware_budget_per_unit_vnd':2000000,'speaker_script_words':sum(len(s['note'].split()) for s in slides),'hardware_price_confirmed':False,'simulation_is_separate':True}
(P/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False))
files=['AnMi_Pitch_10_slide.pptx','AnMi_Pitch_10_slide.pdf','AnMi_Mo_hinh_tai_chinh.xlsx','Loi_thuyet_trinh_va_hoi_dap.md','Co_so_kinh_doanh_va_nguon_v2.pdf','Co_so_kinh_doanh_va_nguon_v2.md','MO_PHONG_200_phan_hoi_KHONG_PHAI_KHAO_SAT.xlsx','Tong_quan_10_slide.jpg']
with zipfile.ZipFile(P/'AnMi_Bo_bao_cao_cap_nhat.zip','w',zipfile.ZIP_DEFLATED) as package:
    for f in files:package.write(P/f,f)
