from pathlib import Path
import sys, json, html, base64, math, shutil
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(OUT/'_lib'))
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from PIL import Image
import xlsxwriter

NAVY='102F36'; MINT='A5E4CE'; PAPER='F5F5ED'; INK='183B40'; MUTED='667E7D'; WHITE='FFFFFF'; ORANGE='F2B27A'; LINE='DCE5DE'
prs=Presentation();prs.slide_width= Inches(16);prs.slide_height= Inches(9)
pages=[];current=None; dark=False
def rect(x,y,w,h,fill,r=0):
    shape=current.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if r else MSO_SHAPE.RECTANGLE, Inches(x/100), Inches(y/100), Inches(w/100), Inches(h/100))
    shape.fill.solid();shape.fill.fore_color.rgb=RGBColor.from_string(fill);shape.line.fill.background()
    if r:
        try:shape.adjustments[0]=.12
        except:pass
    pages[-1]['items'].append(dict(type='rect',x=x,y=y,w=w,h=h,fill=fill,r=r))
def text(s,x,y,w,h,size=28,color=None,bold=False):
    color=color or (WHITE if dark else INK)
    box=current.shapes.add_textbox(Inches(x/100), Inches(y/100), Inches(w/100), Inches(h/100))
    tf=box.text_frame;tf.word_wrap=True;tf.margin_left=tf.margin_right=0;tf.margin_top=tf.margin_bottom=0
    for i,line in enumerate(s.split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.font.name='Arial';p.font.size=Pt(size*.72);p.font.bold=bold;p.font.color.rgb=RGBColor.from_string(color);p.space_after=Pt(size*.12)
    pages[-1]['items'].append(dict(type='text',s=s,x=x,y=y,w=w,h=h,size=size,color=color,bold=bold))
def pic(path,x,y,w,h):
    current.shapes.add_picture(str(path), Inches(x/100), Inches(y/100), Inches(w/100), Inches(h/100))
    pages[-1]['items'].append(dict(type='img',path=str(path),x=x,y=y,w=w,h=h))
def slide(kicker,title,secs,source='',is_dark=False):
    global current,dark
    dark=is_dark;current=prs.slides.add_slide(prs.slide_layouts[6]);current.background.fill.solid();current.background.fill.fore_color.rgb=RGBColor.from_string(NAVY if dark else PAPER)
    pages.append(dict(title=title,secs=secs,source=source,items=[],dark=dark))
    text('COGAI  /  AnMi',64,35,380,35,21,MINT if dark else MUTED,True)
    text(kicker.upper(),64,100,1450,35,20,MINT if dark else MUTED,True)
    text(title,64,150,1470,140,53,None,True)
    rect(64,835,1470,2,'33535A' if dark else LINE)
    text(source,64,850,1360,37,14,'B2C6C5' if dark else MUTED)
    text(f'{len(pages):02d} / 10',1440,850,100,25,17,MINT if dark else MUTED)
def note(s):
    pages[-1]['note']=s
    current.notes_slide.notes_text_frame.text=f"Thời lượng: {pages[-1]['secs']} giây\n{s}\n\nNguồn / giới hạn: {pages[-1]['source']}"
def card(x,y,w,h,title,body,accent=MINT):
    rect(x,y,w,h,'1C4148' if dark else WHITE,15);rect(x+24,y+28,7,45,accent)
    text(title,x+48,y+27,w-70,65,28,None,True);text(body,x+28,y+111,w-55,h-120,25,'C1D5D3' if dark else MUTED)

# Use only supplied project images. Crop the original photograph, with no invented hardware.
assets=OUT/'assets';assets.mkdir(exist_ok=True)
im=Image.open(ROOT/'Hinh anh CogAI/Hinh 5 Thiet bi MYHealth va bieu cam.png')
im.crop((120,325,700,1270)).save(assets/'myhealth.png')

exec(compile((OUT/'pitch_v2_sections.py').read_text(encoding='utf-8'),str(OUT/'pitch_v2_sections.py'),'exec'))

assert sum(p['secs'] for p in pages)==300
prs.save(OUT/'AnMi_Pitch_10_slide.pptx')

# Self-contained HTML mirrors the editable PowerPoint primitives; Chromium exports its PDF.
sections=[]
for idx,p in enumerate(pages):
    els=[]
    for it in p['items']:
        style=f"left:{it['x']}px;top:{it['y']}px;width:{it['w']}px;height:{it['h']}px;"
        if it['type']=='rect':els.append(f'<div class="el" style="{style}background:#{it["fill"]};border-radius:{it["r"]}px;clip-path:{it.get("clip","none")}"></div>')
        elif it['type']=='text':els.append(f'<div class="el txt" style="{style}font-size:{it["size"]}px;color:#{it["color"]};font-weight:{700 if it["bold"] else 400}">{html.escape(it["s"]).replace(chr(10),"<br>")}</div>')
        else:
            uri='data:image/png;base64,'+base64.b64encode(Path(it['path']).read_bytes()).decode()
            els.append(f'<img class="el" style="{style}" src="{uri}">')
    sections.append(f'<section class="slide" id="s{idx+1}" style="background:#{NAVY if p["dark"] else PAPER}">'+''.join(els)+'</section>')
html_doc='''<!doctype html><html lang="vi"><meta charset="utf-8"><title>AnMi — CogAI / Pitch 5 phút</title><style>*{box-sizing:border-box}body{margin:0;background:#dce5de;font-family:Arial,sans-serif}.slide{position:relative;width:1600px;height:900px;overflow:hidden;margin:0 auto 24px;break-after:page}.el{position:absolute}.txt{line-height:1.14;white-space:normal} @page{size:1600px 900px;margin:0}@media print{body{background:white}.slide{margin:0}}</style>'''+''.join(sections)+'''<script>let n=0;const s=[...document.querySelectorAll('.slide')];document.addEventListener('keydown',e=>{if(['ArrowRight','PageDown',' '].includes(e.key)){e.preventDefault();n=Math.min(n+1,9);s[n].scrollIntoView()}if(['ArrowLeft','PageUp'].includes(e.key)){e.preventDefault();n=Math.max(0,n-1);s[n].scrollIntoView()}if(e.key==='Home'){n=0;s[n].scrollIntoView()}})</script></html>'''
(OUT/'AnMi_Pitch.html').write_text(html_doc,encoding='utf-8')
(OUT/'slides.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2),encoding='utf-8')

# Editable financial workbook with cached results and explicit assumptions.
wb=xlsxwriter.Workbook(OUT/'AnMi_Mo_hinh_tai_chinh.xlsx');a=wb.add_worksheet('Gia dinh');f=wb.add_worksheet('Du bao 5 nam');sc=wb.add_worksheet('Do nhay');src=wb.add_worksheet('Nguon va gioi han')
head=wb.add_format({'bold':True,'bg_color':'#102F36','font_color':'white','text_wrap':True});num=wb.add_format({'num_format':'#,##0.0;[Red](#,##0.0)'});inp=wb.add_format({'font_color':'blue','num_format':'#,##0'});wrap=wb.add_format({'text_wrap':True,'valign':'top'});pct=wb.add_format({'num_format':'0.0%'})
a.set_column('A:A',48);a.set_column('B:B',18);a.set_column('C:C',100)
assumptions=[('Giá bình quân / suất / tháng',14000,'Giả định từ dải 12.000–15.000 trong hồ sơ; chưa kiểm chứng mức sẵn sàng trả.'),('Chi phí biến đổi / suất / tháng',5000,'Ngân sách cơ sở; bao gồm AI, voice và hạ tầng tăng thêm. Chưa đo thực tế.'),('Thuế suất giả định',.2,'Chỉ phục vụ mô hình; không kết luận thuế thực tế, chưa tính bù lỗ.'),('Ngân sách năm đầu (triệu đồng)',260,'Toàn bộ chi năm đầu được coi là dòng tiền ra, không cộng lần hai.'),('Lượt chat / suất / tháng',40,'Dự trù sử dụng; cần định nghĩa giới hạn công bằng.'),('Tỷ giá quy đổi USD',26000,'Giả định quy đổi để so sánh; không phải tỷ giá hiện hành.'),('Chi phí biến đổi stress / tháng',8000,'Kiểm tra mức sử dụng cao và phát sinh chi phí.'),('Tỷ lệ số suất ở kịch bản chậm',.7,'Giữ nguyên giá và chi cố định, số suất bằng 70% cơ sở.')]
a.write_row(0,0,['Đầu vào chỉnh sửa','Giá trị','Diễn giải'],head)
for r,(name,val,desc) in enumerate(assumptions,1):a.write(r,0,name);a.write(r,1,val,pct if r in [3,8] else inp);a.write(r,2,desc,wrap);a.set_row(r,42)
a.write(11,0,'Ngân sách năm đầu',head);a.write_row(12,0,['Khoản mục','Triệu đồng'],head)
for r,(name,v) in enumerate([('Hạ tầng và AI',78),('Dữ liệu và chuyên môn',78),('Pháp lý',20),('Thiết bị',30),('Thí điểm',28),('Dự phòng',26)],13):a.write(r,0,name);a.write(r,1,v,inp)
a.write(19,0,'Tổng');a.write_formula(19,1,'=SUM(B14:B19)',num,260)
users=[0,3000,8000,15000,25000];fixed=[260,570,720,1100,1700];rev=[u*14000*12/1e6 for u in users];var=[u*5000*12/1e6 for u in users];pre=[rev[i]-var[i]-fixed[i] for i in range(5)];tax=[max(0,p)*.2 for p in pre];net=[pre[i]-tax[i] for i in range(5)];cum=[]
for n in net:cum.append(n+(cum[-1] if cum else 0))
f.set_column('A:A',42);f.set_column('B:F',21);f.write_row(0,0,['Đơn vị: triệu đồng','Năm 1','Năm 2','Năm 3','Năm 4','Năm 5'],head)
labels=['Kỳ hoạt động','Suất trả phí bình quân cả năm','Doanh thu','Chi biến đổi','Chi cố định / ngân sách khởi tạo','Tổng chi trước thuế','Lãi trước thuế','Thuế giả định (không bù lỗ)','Lãi sau thuế giả định','Dòng tiền giản lược','Lũy kế dòng tiền','Suất hòa vốn vận hành']
for r,l in enumerate(labels,1):f.write(r,0,l)
for i in range(5):
    c=xlsxwriter.utility.xl_col_to_name(i+1);prev=xlsxwriter.utility.xl_col_to_name(i)
    f.write(1,i+1,f'10/{2026+i}–09/{2027+i}')
    f.write(2,i+1,users[i],inp)
    formulas={3:(f'={c}3*\'Gia dinh\'!$B$2*12/1000000',rev[i]),4:(f'={c}3*\'Gia dinh\'!$B$3*12/1000000',var[i]),6:(f'={c}5+{c}6',var[i]+fixed[i]),7:(f'={c}4-{c}7',pre[i]),8:(f'=MAX(0,{c}8)*\'Gia dinh\'!$B$4',tax[i]),9:(f'={c}8-{c}9',net[i]),10:(f'={c}10',net[i]),11:(f'={c}11'+(f'+{prev}12' if i else ''),cum[i])}
    if i==0:f.write_formula(5,i+1,"='Gia dinh'!B5",num,260)
    else:f.write(5,i+1,fixed[i],inp)
    for r,(fo,v) in formulas.items():f.write_formula(r,i+1,fo,num,v)
    if i:f.write_formula(12,i+1,f'={c}6*1000000/((\'Gia dinh\'!$B$2-\'Gia dinh\'!$B$3)*12)',num,fixed[i]*1e6/108000)
f.write(15,0,'Hoàn vốn cơ sở (năm từ 10/2026)');f.write_formula(15,1,'=IF(E12>=0,3+ABS(D12)/E11,IF(F12>=0,4+ABS(E12)/F11,"Chưa hoàn vốn trong 5 năm"))',num,3+390.8/416)
f.write(17,0,'Chi cố định năm 3: 720 triệu',head);f.merge_range('A19:F21','Cơ cấu đề xuất năm 3: nhân sự 420; chuyên môn 120; bán hàng/triển khai 90; hạ tầng nền 48; pháp lý/kế toán/bảo mật 42 (triệu/năm). Đây là ngân sách xây dựng lại, chưa có báo giá. Năm đầu nhóm chưa tính lương sáng lập. Từ năm 2 đã dự trù nhân sự trong chi cố định.',wrap)
f.merge_range('A23:F26','Dòng tiền giản lược bằng lợi nhuận sau thuế: giả định thu và trả trong năm, chưa có vốn lưu động, khấu hao, đầu tư mới và chi phí vốn. Thuế 20% là giả định mô hình; chưa áp dụng bù lỗ hay ưu đãi. Ngân sách 260 triệu năm đầu không phải toàn bộ chi phí cố định. Các năm dùng số suất bình quân, không dùng số cuối năm.',wrap)
sc.set_column('A:A',42);sc.set_column('B:F',22);sc.write_row(0,0,['Kịch bản / năm',1,2,3,4,5],head)
for i in range(5):
    c=xlsxwriter.utility.xl_col_to_name(i+1);base=f"'Du bao 5 nam'!{c}"
    u=users[i]*.7;p=u*108000/1e6-fixed[i];n=p-max(p,0)*.2
    sc.write_formula(1,i+1,f'={base}3*\'Gia dinh\'!$B$9',num,u)
    sc.write_formula(2,i+1,f'={c}2*(\'Gia dinh\'!$B$2-\'Gia dinh\'!$B$3)*12/1000000-{base}6',num,p)
    sc.write_formula(3,i+1,f'={c}3-MAX(0,{c}3)*\'Gia dinh\'!$B$4',num,n)
    last=sum((users[j]*.7*108000/1e6-fixed[j])-max(users[j]*.7*108000/1e6-fixed[j],0)*.2 for j in range(i+1))
    sc.write_formula(4,i+1,f'=SUM($B4:{c}4)',num,last)
for r,l in enumerate(['Suất trả phí: 70% cơ sở','Lãi trước thuế','Lãi sau thuế giả định','Lũy kế dòng tiền'],1):sc.write(r,0,l)
sc.write(7,0,'Biên cơ sở');sc.write_formula(7,1,"=('Gia dinh'!B2-'Gia dinh'!B3)/'Gia dinh'!B2",pct,9/14)
sc.write(8,0,'Biên khi biến phí lên 8.000đ');sc.write_formula(8,1,"=('Gia dinh'!B2-'Gia dinh'!B8)/'Gia dinh'!B2",pct,6/14)
sc.write(10,0,'Hoàn vốn kịch bản chậm');sc.write_formula(10,1,'=IF(F5<0,"Chưa hoàn vốn sau 5 năm","Xem lũy kế")',None,'Chưa hoàn vốn sau 5 năm')
sources=[('WHO 2025','https://www.who.int/publications/i/item/9789240113817','Hơn một tỷ người sống với rối loạn tâm thần.'),('UNICEF Việt Nam 2022','https://www.unicef.org/vietnam/unicef-viet-nam-key-results-2022','21,7% thanh thiếu niên báo cáo vấn đề sức khỏe tâm thần trong năm qua.'),('Thang và cs. 2022','https://pubmed.ncbi.nlm.nih.gov/35712280/','N=1.788 sinh viên ngoại ngữ; 35% triệu chứng lo âu nặng. Không đại diện toàn quốc.'),('Headspace Solo','https://help.headspace.com/hc/en-us/articles/360022693293-What-will-be-the-cost-for-my-subscription-renewal','69,99 USD/năm gia hạn 2026; chưa thuế; giá khác theo vùng và kênh.'),('Headspace Student','https://www.headspace.com/studentplan','9,99 USD/năm; có điều kiện xác minh; không khẳng định áp dụng cho mọi sinh viên VN.'),('Hồ sơ CogAI','Tài liệu/Thuyet minh du an - CogAI.docx','Giá, ngân sách, đội ngũ và trạng thái công bố theo hồ sơ. Dự báo đã được dựng lại.'),('Paper gốc','Paper/*.pdf','Kết quả tiếng Anh, không chứng minh hiệu quả lâm sàng tiếng Việt.'),('Nguyên mẫu','Hinh anh CogAI/Hinh 6 Ket qua kiem thu MYHealth.png','84/84 kiểm thử AI giả lập. Không phải tỷ lệ phát hiện nguy cơ.'),('Tài liệu triển khai bổ sung','cogai/docs/RA_SOAT_DU_AN_2026_10_23.md','Có bản web demo; còn phát hiện cần xử lý trước dữ liệu thật. Không đưa thành tuyên bố đã sẵn sàng triển khai.')]
sources += json.loads((OUT/'sources_v2.json').read_text(encoding='utf-8'))
src.set_column('A:A',26);src.set_column('B:B',65);src.set_column('C:C',100);src.write_row(0,0,['Nguồn','Địa chỉ','Cách sử dụng / giới hạn'],head)
for r,row in enumerate(sources,1):src.write_row(r,0,row,wrap);src.set_row(r,60)
for sh in [a,f,sc,src]:sh.freeze_panes(1,1);sh.hide_gridlines(2)
exec(compile((OUT/'workbook_v2_extra.py').read_text(encoding='utf-8'),str(OUT/'workbook_v2_extra.py'),'exec'))
wb.close()

script=['# AnMi — Lời thuyết trình 5 phút','Tổng thời gian phân bổ: 300 giây. Luyện theo đồng hồ; lời nói có thể nhanh/chậm tùy người. Nội dung cũng nằm trong Notes của PowerPoint.','']
time=0
for i,p in enumerate(pages):
    end=time+p['secs'];script += [f'## Slide {i+1} | {time//60}:{time%60:02d}–{end//60}:{end%60:02d}',p['title'].replace('\n',' '),'',p['note'],''];time=end
script += ['## Trả lời nhanh khi giám khảo hỏi','',
'**Đã có khách hàng trả phí chưa?** Hồ sơ chưa có hợp đồng và bằng chứng doanh thu. Các con số là mục tiêu để kiểm chứng.',
'**Tại sao tính hoàn vốn khác hồ sơ?** Hồ sơ dự tính năm 2 doanh thu 570 triệu trong khi 3.000 × 14.000 × 12 chỉ là 504 triệu; có thể có nguồn thu bổ sung nhưng chưa tách rõ. Bản này chỉ dùng thuê bao tổ chức, dựng lại chi phí và thuế giả định, nên hoàn vốn khoảng 3,94 năm.',
'**Vì sao cần 260 triệu?** Đây là toàn bộ ngân sách khởi tạo và vận hành năm đầu, gồm cả API, chuyên môn và dự phòng. Không gọi toàn bộ là tài sản cố định; không cộng thêm lần nữa vào năm 2.',
'**Chi phí cố định là gì?** Khoản ít thay đổi trong phạm vi quy mô dự kiến: nhân sự, cố vấn nền, hạ tầng nền, bán hàng, pháp lý. Năm 3 dự trù 720 triệu/năm. Biến phí là phần tăng theo suất và mức sử dụng; dự trù 5.000đ/suất/tháng.',
'**Biên 64,3% có phải lợi nhuận ròng?** Không. Đây là biên đóng góp trước chi cố định và thuế. Năm 3 lãi sau thuế giả định 115,2 triệu trên doanh thu 1.344 triệu, tương đương khoảng 8,6%.',
'**Hòa vốn vận hành khác hoàn vốn thế nào?** Hòa vốn vận hành bù chi trong năm; năm 3 cần khoảng 6.667 suất. Hoàn vốn cần bù cả thâm hụt tích lũy từ khi bắt đầu; kịch bản cơ sở đạt cuối năm 4.',
'**Có thể giảm chi phí hơn bao nhiêu?** Chưa có dữ liệu đo trên triển khai thật. Mục tiêu là điều phối mô đun theo nhu cầu, giới hạn công bằng, web trước, đo từng lượt và từng suất. Không lấy chi phí API trong bài báo làm toàn bộ chi phí dịch vụ.',
'**Thuế và dòng tiền đã đầy đủ chưa?** Chưa. 20% là giả định tính toán; mô hình chưa bù lỗ, chưa tính vốn lưu động, đầu tư mới, ưu đãi và khấu hao. Cần kế toán xác lập trước khi gọi là dự báo lợi nhuận ròng kế toán.',
'**Nguồn tài trợ đã có chưa?** Hồ sơ dự kiến 80 triệu vốn nhóm, 80 triệu đồng tài trợ thí điểm, 60 triệu hỗ trợ nghiên cứu/khởi nghiệp, 40 triệu giải thưởng/tài trợ khác. Chưa có chứng từ xác nhận; không trình bày là tiền đã nhận. Khoản gọi vốn 500 triệu năm 2 trong hồ sơ là nguồn tài trợ, không phải doanh thu.',
'**Sản phẩm bảo vệ người dùng thế nào?** Định vị hỗ trợ/sàng lọc, đồng ý dữ liệu, báo cáo tổng hợp, hướng dẫn tìm người thật. Trước thí điểm phải xác nhận cố vấn, quy trình tiếp nhận, quyền dữ liệu và xử lý các lỗi còn mở. Không hứa AI ngăn ngừa mọi khủng hoảng.',
'**AnMi đã có trên giao diện chưa?** Tên thương hiệu trong bộ pitch là AnMi. Một số ảnh demo và mã nguồn hiện còn tên Mầm/MYHealth; bộ tài liệu này không sửa ứng dụng. Trước sân khấu cần thống nhất tên trong demo.',
'','## Nguồn và các việc cần xác nhận trước cuộc thi','']
for name,url,desc in sources:script += [f'- {name}: {url} — {desc}']
script += ['', 'Cần xác nhận: trạng thái/đường dẫn công bố CogRAG; bản demo hiện hành; giá và chi phí từ đo thử; mức vốn thật có; quyền thương mại dữ liệu và công nghệ; đối tác tiếp nhận. Không kể trường hợp sinh viên có thật nếu chưa có nguồn đáng tin và sự phù hợp khi sử dụng câu chuyện. Không quy một trường hợp tử vong do tự sát cho một nguyên nhân đơn lẻ.', '', 'Bộ pitch chọn sinh viên trưởng thành làm phân khúc đầu tiên để tập trung triển khai; đây là đề xuất so với hồ sơ gốc ưu tiên đồng thời công nhân và sinh viên. Kịch bản 10 tổ chức là giả định tiếp cận, không phải TAM quốc gia. Không lấy tỷ lệ có vấn đề tâm lý nhân dân số để suy ra doanh thu.', '', 'Thiết kế: 16:9, nền ngà / xanh trầm / xanh bạc hà; chữ và hình khối trong PPTX sửa được. Thiết bị được minh họa kiểu dáng theo ảnh người dùng; không xác nhận thông số bên trong. Nguồn web được kiểm tra ngày 26/10/2026. Không có slide phụ để giữ đúng 10 trang.']
(OUT/'Loi_thuyet_trinh_va_hoi_dap.md').write_text('\n\n'.join(script),encoding='utf-8')
print(json.dumps({'slides':len(pages),'seconds':sum(p['secs'] for p in pages),'net':net,'cumulative':cum,'payback_years':3+390.8/416},ensure_ascii=False))
