# Khôi phục công cụ tạo tài liệu AnMi

Tệp này nằm trong `Nguon_tao_slide.zip`. Khi cần tạo lại tài liệu, giải nén các tệp vào chính thư mục `Bao cao AnMi` trong dự án gốc.

Môi trường cần Python 3.12 và các thư viện `python-pptx==1.0.2`, `Pillow==13.0.0`, `xlsxwriter==3.3.0`, `lxml==6.1.3`, `typing-extensions==4.16.0`. Cài vào thư mục `_lib` cạnh mã, ví dụ `python -m pip install --target _lib python-pptx==1.0.2 Pillow==13.0.0 xlsxwriter==3.3.0 lxml==6.1.3 typing-extensions==4.16.0`.

Phần render dùng Node.js, Playwright từ `cogai/frontend/node_modules` và Chrome có sẵn trên máy. Mã đọc tài liệu/ảnh từ thư mục dự án gốc, không chạy độc lập nếu thiếu nguồn.

Thứ tự thực hiện từ thư mục gốc dự án:

1. `python "Bao cao AnMi/build_supporting.py"` để dựng thuyết minh nguồn. Script này cũng tạo dữ liệu mô phỏng có nhãn riêng; không dùng nó làm bằng chứng khảo sát thật.
2. `python "Bao cao AnMi/build_pitch.py"` để dựng PowerPoint, Excel, HTML và lời thuyết trình.
3. `node "Bao cao AnMi/render.mjs"` để render PDF và ảnh kiểm tra.
4. `node "Bao cao AnMi/render_supporting.mjs"` để dựng PDF giải thích nguồn.
5. `python "Bao cao AnMi/verify_pitch.py"` để kiểm tra và tạo ảnh tổng quan.
6. `python "Bao cao AnMi/package_for_agent.py"` để đóng gói tài liệu giao agent.

Các mã này là công cụ hỗ trợ, không phải mã ứng dụng CogAI. Không có cookie, thông tin đăng nhập hay nội dung Shopee trong bộ mã lưu trữ.
