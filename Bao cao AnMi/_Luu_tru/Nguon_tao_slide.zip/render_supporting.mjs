import {createRequire} from 'node:module';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const require=createRequire(new URL('../cogai/frontend/package.json',import.meta.url));
const {chromium}=require('@playwright/test');
const base=new URL('./',import.meta.url);
const md=await readFile(new URL('Co_so_kinh_doanh_va_nguon_v2.md',base),'utf8');
const esc=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const inline=s=>esc(s).replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g,'<a href="$2">$1</a>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>');
const lines=md.split('\n');let content='',table=false;
for(const line of lines){
if(line.startsWith('|')){
if(/^\|[\s:|\-]+\|$/.test(line))continue;
if(!table){content+='<table>';table=true}
content+='<tr>'+line.split('|').slice(1,-1).map(x=>`<td>${inline(x.trim())}</td>`).join('')+'</tr>';continue;
}
if(table){content+='</table>';table=false}
if(!line.trim())continue;
if(line.startsWith('## '))content+=`<h2>${inline(line.slice(3))}</h2>`;
else if(line.startsWith('# '))content+=`<h1>${inline(line.slice(2))}</h1>`;
else if(line.startsWith('- '))content+=`<p class="source">${inline(line.slice(2))}</p>`;
else content+=`<p>${inline(line)}</p>`;
}
if(table)content+='</table>';
const doc=`<!doctype html><html lang="vi"><meta charset="utf-8"><title>AnMi — Cơ sở kinh doanh và nguồn</title><style>@page{size:A4;margin:18mm 17mm}body{font:11pt/1.5 Arial,sans-serif;color:#183b40;margin:0}h1{font-size:25pt;color:#102f36;line-height:1.2}h2{font-size:17pt;line-height:1.25;margin-top:22pt;break-after:avoid}p{margin:0 0 10pt;orphans:3;widows:3}a{color:#00786a;overflow-wrap:anywhere}table{width:100%;border-collapse:collapse;font-size:10pt;margin:12pt 0;break-inside:avoid}td{border-bottom:1px solid #dce5de;padding:7pt}tr:first-child{background:#e6eee7;font-weight:bold}.source{font-size:9.5pt;overflow-wrap:anywhere}code{font-family:Arial,sans-serif;background:#eef2ed}strong{color:#102f36}</style>${content}</html>`;
await writeFile(new URL('Co_so_kinh_doanh_va_nguon_v2.html',base),doc);
const browser=await chromium.launch({channel:'chrome',headless:true});
try{const page=await browser.newPage();await page.setContent(doc);await page.pdf({path:fileURLToPath(new URL('Co_so_kinh_doanh_va_nguon_v2.pdf',base)),printBackground:true,preferCSSPageSize:true});console.log('Supporting PDF rendered')}finally{await browser.close()}
