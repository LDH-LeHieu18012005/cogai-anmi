# ĐỌC TRƯỚC — BỘ TÀI LIỆU THIẾT KẾ ANMI

Làm theo `01_PROMPT.md`. Mục tiêu: thiết kế hoàn chỉnh 10 slide / 5 phút, xuất PPTX chỉnh sửa được và PDF.

## Thứ tự đọc
1. Prompt và thuyết minh trong `02_HO_SO_GOC/`.
2. Excel và bản giải thích trong `03_KINH_DOANH_VA_NGUON/`.
3. Bản slide tham khảo và speaker notes trong `04_SLIDE_HIEN_TAI/`.
4. Paper và hình pipeline/giao diện trong các thư mục còn lại.

## Thiết bị hiện tại
Người dùng xác nhận mẫu Quỷ nhỏ thông thái / Monter Desk AI: thân trắng có sừng, khung mặt tím, màn hình chữ nhật. Hai ảnh phải được đính kèm cùng cuộc giao việc hoặc đặt vào `08_ANH_QUY_NHO_CAN_BO_SUNG/`.

Ảnh EchoEar/MYHealth màn hình tròn trong tài liệu gốc là tư liệu lịch sử của mẫu khác. KHÔNG thay thế cho ảnh Quỷ nhỏ, KHÔNG áp giá/thông số hay 84/84 kiểm thử sang mẫu Quỷ nhỏ.

2 triệu đồng/bộ là hạn mức theo thuyết minh, chưa phải giá thị trường. Dự báo 3,94 năm hoàn vốn là mô hình có giả định, không phải thành tích đã đạt. Các sheet khảo sát còn trống. Không có dữ liệu khảo sát người dùng thật trong bộ giao việc này.

## Tư liệu gốc
Các tài liệu gốc được giữ nguyên, có thể chứa trạng thái cũ hoặc dự báo đã được điều chỉnh. Xem thứ tự ưu tiên trong prompt. Các số liệu cần có nguồn, kỳ dữ liệu và phạm vi.
