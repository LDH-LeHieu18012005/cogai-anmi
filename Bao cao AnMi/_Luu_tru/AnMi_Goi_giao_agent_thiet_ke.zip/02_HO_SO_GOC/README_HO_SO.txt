HỒ SƠ DỰ THI: CogAI
Hệ sinh thái AI sàng lọc sớm và hỗ trợ sức khỏe tinh thần dựa trên tái cấu trúc nhận thức (Cognitive Reframing)

Cuộc thi khởi nghiệp, đổi mới sáng tạo tỉnh Hưng Yên năm 2026
Nhóm công trình: Dự án khởi nghiệp (đang xây dựng sản phẩm)
Đại diện nhóm: Lê Dương Hiếu, Khoa CNTT, Trường Đại học Công nghệ Kỹ thuật Hưng Yên
Liên hệ: 0397860423 · hieuleduonghy@gmail.com


1. GIỚI THIỆU NGẮN

CogAI giúp công nhân khu công nghiệp và sinh viên nhận ra sớm khi mình "không ổn",
tự chăm sóc bằng kỹ thuật tái cấu trúc nhận thức của liệu pháp nhận thức hành vi (CBT),
và được chuyển tới người thật (đường dây nóng, chuyên gia tâm lý) khi có dấu hiệu nguy cơ.
CogAI không chẩn đoán, không điều trị và không thay thế chuyên gia.

Sản phẩm dùng một lõi AI cho bốn kênh: web chatbot (đang xây dựng), thiết bị trò chuyện
để bàn MYHealth (đã có nguyên mẫu), ứng dụng điện thoại và đồng hồ (theo kế hoạch).
Công nghệ lõi gồm CogRAG, CARE và EviOCEAN, là kết quả nghiên cứu của nhóm.


2. CẤU TRÚC THƯ MỤC

  CogAI
  ├── README.txt              Tệp này
  ├── Tài liệu                Hồ sơ đăng ký theo mẫu của Cuộc thi
  ├── Hinh anh CogAI          9 hình minh họa được dẫn chiếu trong Thuyết minh
  └── Paper                   3 bài báo khoa học về công nghệ lõi


3. THƯ MỤC "Tài liệu"

  Phiếu đăng ký dự thi (Mẫu 1a)
      Tên dự án, danh sách 5 tác giả, hồ sơ kèm theo, chữ ký đại diện.

  Thuyết minh dự án (Mẫu 2)
      Nội dung chính của hồ sơ, gồm 7 mục theo mẫu:
      1. Mô tả tổng quát: bối cảnh, giải pháp, luồng xử lý, kết quả nghiên cứu, nguyên mẫu MYHealth
      2. Thương mại hóa, thị trường
      3. Nguồn lực thực hiện: nhân lực, tài chính, điều kiện cần thiết
      4. Kế hoạch hành động
      5. Kết quả, lợi ích kinh tế, xã hội, môi trường
      6. Khó khăn, thách thức, giải pháp, kiến nghị
      7. Định hướng phát triển

  Gợi ý: đọc Thuyết minh trước, sau đó xem các hình theo số được dẫn chiếu trong bài.


4. THƯ MỤC "Hinh anh CogAI"

  Hình 1  Pipeline toàn hệ thống CogAI
          Đường đi của dữ liệu từ người dùng qua bốn kênh, cổng vào, máy chủ điều phối,
          lớp an toàn và chuyển tuyến, dịch vụ AI, dữ liệu và tổ chức; có nhãn trạng thái
          từng thành phần (đã có nguyên mẫu, đang xây dựng, theo kế hoạch).

  Hình 2  Luồng xử lý một tin nhắn
          Sáu bước xử lý với một ví dụ cụ thể và nhánh xử lý khi có nguy cơ cao.

  Hình 3  Kết quả nghiên cứu công nghệ lõi
          So sánh CogRAG, CARE, EviOCEAN với phương pháp nền (số liệu từ các bài báo).

  Hình 4  Hệ thống nguyên mẫu MYHealth
          Sơ đồ thiết bị để bàn, máy chủ, dịch vụ AI, hồ sơ và trang quản trị.

  Hình 5  Thiết bị MYHealth và biểu cảm
          Ảnh thiết bị, các biểu cảm theo cảm xúc và phản hồi khi cần ưu tiên an toàn.

  Hình 6  Kết quả kiểm thử MYHealth
          84/84 ca kiểm thử phần mềm đạt (06/10/2026); dịch vụ AI được giả lập.

  Hình 7  Phác thảo màn hình trò chuyện (web chatbot)
  Hình 8  Phác thảo màn hình sàng lọc PHQ-9, GAD-7
  Hình 9  Phác thảo màn hình hỗ trợ khẩn cấp
          Hình 7 đến 9 là phác thảo với dữ liệu minh họa, không phải ảnh chụp sản phẩm hoàn thiện.


5. THƯ MỤC "Paper"

  Reframe to Retrieve: Cognition-aware RAG with Projections Inspired by Appraisal and CBT
  for Conversational Mental Health Support (CogRAG)
      Truy hồi và sinh phản hồi theo mô hình nhận thức, kèm thẻ kế hoạch an toàn.
      Đã được chấp nhận đăng tại EMNLP 2026 Findings; được Quỹ NAFOSTED tài trợ
      (mã số 102.05-2025.60). Hai thành viên nhóm là đồng tác giả.

  CARE: Cognitive Appraisal-gated Reasoning for Multimodal Emotion Recognition in Conversations
      Nhận diện cảm xúc trong hội thoại dựa trên đánh giá nhận thức (appraisal).
      Bản thảo đang bình duyệt.

  Diving into the OCEAN: Coarse-to-Fine Evidence Validation for Zero-Shot Big Five Inference
  (EviOCEAN)
      Suy luận tính cách Big Five, phân biệt trạng thái tạm thời với nét tính cách ổn định.
      Bản thảo đang bình duyệt.

  Vai trò trong CogAI: CogRAG tạo phản hồi tái cấu trúc nhận thức; CARE hiểu trạng thái
  cảm xúc của người dùng; EviOCEAN điều chỉnh cách trò chuyện theo từng người.
  Các kết quả thực nghiệm dùng dữ liệu tiếng Anh, không phải thử nghiệm lâm sàng.


6. LƯU Ý

  Các số liệu tài chính trong Thuyết minh (đầu tư, giá, doanh thu, NPV, IRR) là ước tính
  ban đầu của nhóm, sẽ được cập nhật sau khảo sát và thí điểm.
